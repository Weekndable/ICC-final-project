let staircase, stairdim;
let bh;
let a = 0;
let av = 0.0005;
let zoom, tzoom;
let plight;
let orient;
let torient;
let r1, r2;
let cam;
let balls = [];
let shakeIntensity = 0; // Initial shake intensity

let backgrounds = []; // Array to store background images
let currentBackground; // Variable to store the current background image

let font;
let beforeSound;
let afterSound;
let spaceSound;

let szoom = 1.5;
let b = 0;
let bv = 0.005;

class Ball {
  constructor(aoff) {
    this.aoff = aoff;
    this.col = color(random(150), random(150), random(150));
    this.jh = random(2, 7);
  }

  show() {
    this.jh = 2 + 5 * noise(this.aoff + frameCount / 200);
    push();
    rotateZ(a + this.aoff);
    translate(-r1, 0, 100);
    rotateY(-((a + this.aoff) * 12) + a / 360);
    translate(-r2, -(stairdim.y) - (HALF_PI * bh), 0);
    fill(this.col);
    translate(0, -(this.jh * bh * (abs(cos((a + this.aoff) * 180)) + cos((a + this.aoff) * 360) / 24)), 0);
    
    // Adding a random shake to each ellipsoid's position
    translate(random(-shakeIntensity, shakeIntensity), random(-shakeIntensity, shakeIntensity), random(-shakeIntensity, shakeIntensity));
    
    ellipsoid(bh * (1 + sin((a + this.aoff) * 360) / 12), bh * (1 + cos((a + this.aoff) * 360) / 12), bh * (1 + sin((a + this.aoff) * 360) / 12));
    pop();
  }
}

function preload() {
  // Load background images
  backgrounds.push(loadImage('asset/IMG_1387.PNG'));
  backgrounds.push(loadImage('asset/IMG_1388.PNG'));
  backgrounds.push(loadImage('IMG_1302.png'));
  backgrounds.push(loadImage('IMG_1301.png'));
  
  font = loadFont('DNFBitBitv2.ttf');
  
  soundFormats('wav');
  beforeSound = loadSound('asset/sound1.wav');
  afterSound = loadSound('asset/sound2.wav');
  spaceSound = loadSound('asset/sound3.wav');
}

function setup() {
  a = 0;
  createCanvas(windowHeight, windowHeight, WEBGL);
  stairdim = createVector(height / 120, height / 300, height / 120);
  staircase = buildGeometry(() => {
    r1 = height / 3;
    r2 = height / 24;
    bh = height / 320;
    let count = 0;
    for (let a1 = 0; a1 < TAU; a1 += PI / 180) {
      let a2 = 12 * a1;
      push();
      rotateZ(a1);
      translate(r1, 0, 100);
      rotateY(a2);
      translate(r2, 0, 0);
      fill(140 + 115 * sin(a2));
      count += 1;
      cylinder(stairdim.x, stairdim.y);
      pop();
    }
  });

  balls.push(new Ball(0));

  zoom = 0.5;
  tzoom = 0.1;
  plight = createVector(0, 0, 0);
  orient = createVector(0, PI, 0);
  torient = createVector(0, HALF_PI, 0);
  cam = createCamera();
  cam.perspective(PI / 36.0, width / height, 0.1, 3 * height);
  noCursor();

  // Set the initial background image
  currentBackground = random(backgrounds);
  // Apply the initial background

  textFont(font);
  textSize(80);
  textAlign(CENTER, CENTER);
}

function draw() {
  zoom = lerp(zoom, tzoom, 0.01);
  orient.lerp(torient, 0.1);
  if (frameCount == 225){
    beforeSound.play();
  }
  if (frameCount >= 300 && szoom >= 0.12) {
    szoom -= 0.001;
  }
  if (szoom <= 0.12) {
    b += bv
    rotateX(-PI / 2);
    rotateZ(-HALF_PI);
  }
  if (szoom < 0.121 && szoom >= 0.120) {
    afterSound.play();
  }

  scale(szoom);
  rotateY(orient.y);
  rotateZ(orient.x);
  ambientLight(180);
  
  // Apply global shake effect to the camera
  translate(random(-shakeIntensity, shakeIntensity), random(-shakeIntensity, shakeIntensity), random(-shakeIntensity, shakeIntensity));

  plight.lerp(createVector(width / 2 - mouseX, -height + mouseY, height), 0.1);
  pointLight(200, 200, 200, plight.x, plight.y, plight.z);
  background(0);
  applyBackground();  
  noStroke();
  rotateZ(-a);

  // Draw the balls
  for (let b of balls) {
    b.show();
  }

  specularMaterial(100);
  shininess(10);
  model(staircase);
  a += av;
}


function mouseClicked() {
  // 마우스 클릭 시 각 공의 색상을 랜덤하게 변경
  for (let b of balls) {
    b.col = color(random(150), random(150), random(150));
  }
}

function keyPressed() {
  if (keyCode === 32) { // Check if spacebar is pressed
    // Increase the shake intensity when the spacebar is pressed
    shakeIntensity = 5;
    // Change the background image to a random one
    currentBackground = random(backgrounds);
    // Apply the new background
    applyBackground();
    spaceSound.play();
  }
}

function keyReleased() {
  // Reset shake intensity when the spacebar is released
  shakeIntensity = 0;
  spaceSound.stop();
}

function applyBackground() {
  translate(0, 0, -100);
  image(currentBackground, -width/2, -height/2, width, height);
  
  textAlign(LEFT, TOP); // 텍스트 정렬 설정
  push();
  rotateZ(HALF_PI); // 90도 회전
  text('ME?', -width / 2 + 50, -height / 2 + 35); // 텍스트 위치 수정
  pop();
  
  textAlign(RIGHT, BOTTOM);
  push();
  rotateZ(HALF_PI);
  if (currentBackground == backgrounds[0]) {
    text('2016', width / 2 - 50, height / 2 - 30);
  } else if (currentBackground == backgrounds[1]) {
    text('2025', width / 2 - 50, height / 2 - 30);
  } else if (currentBackground == backgrounds[2]) {
    text('2008', width / 2 - 50, height / 2 - 30);
  } else if (currentBackground == backgrounds[3]) {
    text('2015', width / 2 - 50, height / 2 - 30);
  }
  pop();
}
